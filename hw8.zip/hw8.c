   #include<stdio.h>
   #include<stdlib.h>
struct time
{
    int min ;
    int sec;
};
struct runner
{
    char firstname[25];
    char lastname[25];
    int ID;
    struct time *record;
    struct time runningtime;

};
int main()
{
    int n;
    printf("Enter a number");
    scanf("%d",&n);
    struct runner b[n];
    for (int i=0;i<n;i++)
    {
        printf("Enter the name\n");
        scanf("%s",b[i].firstname);
        printf("Enter the lastname\n");
        scanf("%s",b[i].lastname);
        printf("Enter ID\n");
        scanf("%d",&b[i].ID);
        b[i].record=(struct time*)malloc(sizeof(struct time));
        printf("Enter the record min and sec");
        scanf("%d",&b[i].record->min);
        scanf("%d",&b[i].record->sec);
        printf("Enter the ruuningtime min and sec");
        scanf("%d",&b[i].runningtime.min);
        scanf("%d",&b[i].runningtime.sec);
    }
    int win=0;
    for(int i=0;i<n;i++)
    {
        if (b[i].runningtime.min<b[win].runningtime.min || (( b[i].runningtime.min==b[win].record->min)&&
        (b[i].runningtime.sec<b[win].record->sec)))
        {
            win=i;
        }
    }
    printf("firstname\t\tlastname\t\tID\n");
    printf("%s\t\t%s\t\t%d\n",b[win].firstname,b[win].lastname,b[win].ID);
    if (b[win].runningtime.min<b[win].record->min || ((b[win].runningtime.min==b[win].record->min)&&
    b[win].runningtime.sec<b[win].record->sec))

        {
            printf("the participant has broken his own record\n");
        }
        else 
    {
        printf("the participant has not broken his own record\n");

        }

        int flag=0;
        for(int i=0;i<n;i++)
        {
            if(i!=win && (b[win].runningtime.min<b[i].record->min || (b[win].runningtime.min==b[i].record->min && 
            b[win].runningtime.sec<b[i].record->min)))
            {
                flag=1;
                break;
            }

        }
        if (flag)
        {
            printf("The participant has the best record\n");
        }
        else
        {
            printf("The participant doesn't have the best record \n");
        }

        for (int i=0;i<n;i++)
        {
            for(int j=i+1;j<n;j++)
            {
                int x1=b[i].runningtime.min*60+b[i].runningtime.sec;
                int x2=b[j].runningtime.min*60+b[j].runningtime.sec;
                if(x1>x2)
                {
                    struct runner a=b[i];
                    b[i]=b[j];
                    b[j]=a;
                }
            }
        }
        
        printf("firstname\t\tlastname\t\tID\t\trecod(min)\trecord(sec)\trunningtime(min)\trunningtime(sec)\n");
        for (int i=0;i<n;i++)
        {
            printf("%-15s%-15s%-10d%-5d%-10d\t\t%-5d%-5d\n",b[i].firstname,b[i].lastname,b[i].ID,
            b[i].record->min,b[i].record->sec,b[i].runningtime.min,b[i].runningtime.sec);

            free(b[i].record);
        }

    }


    





